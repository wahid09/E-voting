-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 26, 2013 at 07:40 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `evoting`
--

-- --------------------------------------------------------

--
-- Table structure for table `password`
--

CREATE TABLE IF NOT EXISTS `password` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `password`
--

INSERT INTO `password` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `matric_no` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `matric_no`, `password`, `status`) VALUES
(1, '10/52ha109', 'ola', 1),
(2, '10/52ha110', 'welcome', 0),
(3, '09/52ha001', 'olajide', 1),
(4, '09/52ha002', 'kasali', 1),
(5, '09/52ha003', 'jacob', 0),
(6, '09/52hj001', 'mathew', 0),
(7, '09/52hp004', 'oladele', 0),
(8, '09/52hn010', 'Rufai', 0),
(9, '10/52ha115', 'Raheem', 0),
(10, '09/52ha102', 'Udeaja', 0),
(11, '09/52hn009', 'adewale', 0),
(12, 'nd/07/com/088', 'waslam', 0),
(13, 'HND/08/STA/223', '1234', 0),
(14, '08/52HA048', 'HARUN', 1),
(15, '07/52ha154', 'abiodun', 1),
(16, '1234HA', '1234', 1);

-- --------------------------------------------------------

--
-- Table structure for table `voters`
--

CREATE TABLE IF NOT EXISTS `voters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post` int(4) NOT NULL,
  `userid` int(4) NOT NULL,
  `cont_id` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=68 ;

--
-- Dumping data for table `voters`
--

INSERT INTO `voters` (`id`, `post`, `userid`, `cont_id`) VALUES
(47, 4, 3, 9),
(46, 3, 3, 8),
(45, 2, 3, 5),
(44, 1, 3, 3),
(43, 4, 1, 9),
(42, 3, 1, 6),
(41, 2, 1, 4),
(40, 1, 1, 1),
(39, 4, 13, 9),
(38, 3, 13, 6),
(37, 2, 13, 4),
(65, 2, 16, 5),
(64, 1, 16, 1),
(63, 4, 15, 9),
(62, 3, 15, 8),
(61, 2, 15, 4),
(60, 1, 15, 1),
(59, 4, 14, 0),
(58, 3, 14, 8),
(57, 2, 14, 5),
(56, 1, 14, 1),
(55, 4, 4, 0),
(54, 3, 4, 0),
(53, 2, 4, 0),
(52, 1, 4, 0),
(51, 4, 4, 0),
(50, 3, 4, 6),
(49, 2, 4, 5),
(48, 1, 4, 10),
(36, 1, 13, 1),
(66, 3, 16, 6),
(67, 4, 16, 9);
